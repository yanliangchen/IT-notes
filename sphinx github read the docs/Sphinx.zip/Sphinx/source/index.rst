.. MING's BLOG documentation master file, created by
   sphinx-quickstart on Sat Jun 23 16:57:48 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to MING's BLOG's documentation!
=======================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:
   
   how_to_be_a_rich_man

